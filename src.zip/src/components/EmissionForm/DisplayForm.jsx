import React from 'react'

const DisplayForm = () => {
  return (
    <div>
      
    </div>
  )
}

export default DisplayForm
